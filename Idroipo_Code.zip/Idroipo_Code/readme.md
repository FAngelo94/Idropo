# TESTED METHODS
* void showDisplay(String face)
* void lightDisplay(boolean light)
* void playAudio(String audio) [Without if condition, I just try simple code for df player]
* void resetTime()
* void readTime()
* void writeTime()
